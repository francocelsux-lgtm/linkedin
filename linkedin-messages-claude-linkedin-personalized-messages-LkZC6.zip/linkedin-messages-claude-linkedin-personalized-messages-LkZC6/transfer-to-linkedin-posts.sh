#!/bin/bash
# Transferir la carpeta outreach-personalizado al repo linkedin-posts
# Uso: ./transfer-to-linkedin-posts.sh <ruta-local-del-repo-linkedin-posts>
#
# Ejemplo:
#   ./transfer-to-linkedin-posts.sh ../linkedin-posts

set -e

TARGET_REPO="${1}"

if [ -z "$TARGET_REPO" ]; then
  echo "Error: indicá la ruta del repo destino."
  echo "Uso: ./transfer-to-linkedin-posts.sh <ruta-del-repo>"
  exit 1
fi

if [ ! -d "$TARGET_REPO/.git" ]; then
  echo "Error: '$TARGET_REPO' no parece un repositorio git."
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE="$SCRIPT_DIR/outreach-personalizado"
DEST="$TARGET_REPO/outreach-personalizado"

echo "Copiando $SOURCE → $DEST"
cp -r "$SOURCE" "$TARGET_REPO/"

cd "$TARGET_REPO"
git add outreach-personalizado/
git commit -m "Agregar carpeta outreach-personalizado desde linkedin-messages

Contexto completo de Celsux para mensajes LinkedIn: voz, servicios,
prompt, playbook y protocolo de investigación de prospectos."

echo ""
echo "Listo. Ahora podés hacer: git push -u origin <tu-rama>"
