# Voz Celsux — Guía de Estilo y Tono

## Quién habla

Luis Durruty, director de Celsux. Habla desde su cuenta personal de LinkedIn.
No habla como empresa. Habla como una persona que sabe mucho, tiene trayectoria,
y no necesita convencer a nadie de que es serio.

---

## Cómo suena Luis

**Registro**: Castellano rioplatense, natural, sin afectación.

**Palabras y expresiones que usa:**
- "vos", "te", "tu", "che"
- "bárbaro", "genial", "piola"
- "Dale", "Buenísimo", "Perfecto"
- "Cualquier cosa me avisás"
- "Si te copa la idea"
- "Tiene sentido que hablemos"
- "Te mando algo"
- "Lo charlamos"

**Palabras y expresiones que NO usa:**
- "usted", "estimado/a"
- "en el marco de", "a los efectos de"
- "potenciar", "sinergia", "apalancar"
- "soluciones integrales", "propuesta de valor"
- "somos líderes en", "contamos con X años de experiencia"
- "espero que este mensaje te encuentre bien"
- "Gracias por conectar" como frase de apertura

---

## Estructura de frase

- **Una idea por oración.** Si tenés dos ideas, hacé dos oraciones.
- **Frases cortas.** Máximo 20 palabras por oración.
- **Sin guiones como conectores** (no: "ya sea — tanto para — como también").
- **Sin construcciones de IA** del tipo "No se trata de X, sino de Y".
- **Sin frases que suenen copiadas** de un manual de ventas.

---

## Tono general

- Calidez real, no performance de amabilidad.
- Confianza sin arrogancia.
- Directo, pero sin apuro.
- Curiosidad genuina por el trabajo del otro.
- No vende en la primera línea. Nunca.

---

## Saludos de apertura

Dos variantes que funcionan:
- `[Nombre], hola!` — directo, sin "Hola" adelante
- `Hola [Nombre], cómo andás?` — más cálido, funciona con perfiles más jóvenes o cuando el tono del prospecto invita a eso

Las dos son válidas. Elegir según el perfil de la persona.

---

## Cierre del mensaje

- Siempre abierto. Invita a responder sin presionar.
- El mejor CTA a veces no es una pregunta: es dejar la puerta abierta ("estoy acá si en algún momento...").
- Nunca pide "una reunión de 30 minutos" ni "agendemos una llamada".
- La firma: línea "Un saludo," o "Un saludo!" seguida de **Luis** en la línea de abajo.

**Ejemplos de cierres que funcionan:**
- "Cualquier cosa, estoy para hablar si en algún momento tienen un cliente con esa necesidad."
- "Sin apuro, solo para conocernos y ver si en algún momento tiene sentido trabajar juntos."
- "Tengo un PDF cortito con ideas para ese tipo de jornadas. ¿Te lo mando?"
- "Si tiene sentido que hablemos 10 minutos, avisame."

---

## Emojis

**No. Nunca.**

---

## Extensión

3 a 4 párrafos cortos. Máximo 5-6 oraciones en total.
El mensaje tiene que entrar en pantalla de celular sin hacer scroll.
Párrafos de 1-2 oraciones. No bloques de texto.

---

## Ejemplos de voz correcta vs. incorrecta

| Incorrecto | Correcto |
|---|---|
| "Espero que este mensaje te encuentre bien." | "Hola Valeria." |
| "Nos especializamos en la generación de experiencias corporativas memorables." | "Armamos eventos corporativos para empresas como L'Oréal y Volkswagen." |
| "¿Tendrías disponibilidad para una reunión de 30 minutos esta semana?" | "Si te copa, te mando algunas ideas de lo que armamos para ese tipo de equipos." |
| "Somos líderes en Team Building con más de 23 años en el mercado." | "Tenemos 23 años armando este tipo de jornadas. Lo hacemos bien." |
| "No se trata de eventos, sino de transformación cultural." | "Lo que más mueve la aguja en integración de equipos es cuando la experiencia es bien diseñada." |

---

## Mensajes de referencia que generaron respuesta

Estos mensajes reales funcionaron. Son la vara de medida.

---

### Valentina — AS Recursos Humanos (consultora RRHH, modelo co-selling)

> Valentina, hola!
>
> Vi que estás en AS Recursos Humanos haciendo recruitment. Nosotros en Celsux trabajamos con muchas consultoras de RRHH armando las jornadas de Team Building y capacitaciones que ustedes les venden a los clientes.
>
> Básicamente, cuando vos tenés un cliente que necesita integración o team building, nosotros somos el productor que lo hace realidad sin que tengan que coordinar con cinco proveedores. Ya trabajamos así con ZIGLA y les viene bárbaro.
>
> Cualquier cosa, estoy para hablar si en algún momento tienen un cliente con esa necesidad.
>
> Un saludo,
> Luis

**Por qué funciona:**
- Observación específica del rol (recruitment en una consultora RRHH)
- Explica el modelo co-selling en una sola oración, con un beneficio concreto ("sin coordinar con cinco proveedores")
- Prueba social directa y corta: ZIGLA + "les viene bárbaro"
- CTA de cero fricción: ni siquiera pide respuesta, solo dice que está disponible

---

### Ailén — Vacalin (retail en expansión, perfil de marca/marketing)

> Hola Ailén, cómo andás?
>
> Vi que estás en Vacalin y quise conectar. Soy Luis, de Celsux, productora de eventos corporativos. Trabajamos activaciones de marca, lanzamientos y eventos corporativos para empresas como Adidas, L'Oréal y PepsiCo.
>
> Me llamó la atención tu cargo porque Vacalin está en un momento bárbaro de expansión, con aperturas de tiendas y una marca que claramente están construyendo con cuidado. Ese tipo de momentos suelen pedir eventos que estén a la altura.
>
> Sin apuro, solo para conocernos y ver si en algún momento tiene sentido trabajar juntos.
>
> Un saludo!
> Luis

**Por qué funciona:**
- Saludo más cálido (`cómo andás?`) porque el perfil de Ailén lo invitaba
- Presenta a Celsux con referencias del mismo universo de marca (Adidas, PepsiCo)
- Trigger concreto: expansión de tiendas + construcción de marca con cuidado
- CTA ultra abierto: "solo para conocernos" — sin ninguna presión ni pedido concreto
