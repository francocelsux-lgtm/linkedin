# Outreach Personalizado — LinkedIn Celsux

Sistema de mensajes ultrapersonalizados para LinkedIn, en nombre de Luis Durruty
(director de Celsux), dirigidos a contactos de RRHH, People, Cultura y Bienestar.

---

## Flujo de trabajo

```
1. Investigar prospecto       →  protocolo-intel.md
2. Elegir servicio y ángulo   →  servicios-celsux.md
3. Generar el mensaje         →  prompt-mensajes.md  (+ voz-celsux.md)
4. Enviar en LinkedIn         →  playbook-linkedin.md
```

---

## Archivos

| Archivo | Para qué sirve |
|---|---|
| `prompt-mensajes.md` | Prompt completo para generar el mensaje con IA |
| `voz-celsux.md` | Guía de tono y estilo. Leer siempre antes de escribir |
| `servicios-celsux.md` | Catálogo de servicios y tabla de matching cargo-servicio |
| `playbook-linkedin.md` | Las 4 fases del proceso: calentamiento, conexión, DM, retargeting |
| `protocolo-intel.md` | Cómo investigar al prospecto y construir el perfil antes de escribir |

---

## Reglas no negociables

1. **Primero intel, después mensaje.** Sin trigger real, no se escribe.
2. **Siempre leer `voz-celsux.md`** antes de generar cualquier texto.
3. **El objetivo del mensaje es UNA respuesta**, no una reunión ni una venta.
4. **Firma siempre: Luis.** Nunca "Celsux" en los mensajes de outreach.
5. **Máximo 5-6 oraciones.** Tiene que entrar en pantalla de celular.

---

## Tipos de prospecto

- **RRHH / People / Talento** en empresa de +50 empleados → `prompt-mensajes.md` Variante A
- **Cultura / Bienestar / Engagement** → Variante B
- **Gerente/Directora RRHH con equipo distribuido** → Variante C
- **Consultora de RRHH** (modelo co-selling, no cliente) → Variante D
